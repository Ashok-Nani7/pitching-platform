import PitchForm from "../../../components/PitchForm";

export default function CreatePitchPage() {
  return (
    <div className="p-3 max-w-5xl mx-auto">
      <PitchForm />
    </div>
  );
}
